package com.cte.emissor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmissorCteApplicationTests {

	@Test
	void contextLoads() {
	}

}
