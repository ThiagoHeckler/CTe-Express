package com.cte.emissor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmissorCteApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmissorCteApplication.class, args);
	}

}
