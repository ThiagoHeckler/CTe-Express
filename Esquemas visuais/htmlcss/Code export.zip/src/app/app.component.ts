import { Component } from '@angular/core';
import type { OnInit } from '@angular/core';

@Component({
  selector: 'emitidos-root',
  templateUrl: './app.component.html',
})
export class AppComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {}
}
