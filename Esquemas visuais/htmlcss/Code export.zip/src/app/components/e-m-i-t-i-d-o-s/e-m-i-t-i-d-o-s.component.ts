import { Component } from '@angular/core';
import type { OnInit } from '@angular/core';

/* @figmaId 72:82 */
@Component({
  selector: 'emitidos-e-m-i-t-i-d-o-s',
  templateUrl: './e-m-i-t-i-d-o-s.component.html',
  styleUrls: ['./e-m-i-t-i-d-o-s.component.scss'],
})
export class EMITIDOSComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {}
}
