import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { EMITIDOSComponent } from './components/e-m-i-t-i-d-o-s/e-m-i-t-i-d-o-s.component';

@NgModule({
  declarations: [AppComponent, EMITIDOSComponent],
  imports: [BrowserModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
