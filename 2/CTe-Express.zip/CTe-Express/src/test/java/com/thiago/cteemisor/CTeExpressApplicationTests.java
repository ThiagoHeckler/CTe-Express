package com.thiago.cteemisor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CTeExpressApplicationTests {

	@Test
	void contextLoads() {
	}

}
